# accept integers to sum
print('Enter integer values to sum up')
a = int(input())
b = int(input())

answer = a + b
print('The result is:', answer)